import React, { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { Foliage } from './Foliage';
import { Ornaments } from './Ornaments';
import { Polaroids } from './Polaroids';
import { TreeTopper } from './TreeTopper';
import { Snow } from './Snow';
import { COLORS, CONFIG } from '../constants';
import { useStore } from '../store';
import * as THREE from 'three';

const CameraController = () => {
  const { handPosition, isCameraActive } = useStore();
  const vec = new THREE.Vector3();

  useFrame((state) => {
    if (isCameraActive) {
      // Map hand X/Y (-1 to 1) to camera view angle
      // Hand X moves camera Azimuth, Hand Y moves Polar slightly
      const x = handPosition.x * 10;
      const y = handPosition.y * 5 + 4; // Center at height 4
      
      state.camera.position.lerp(vec.set(x, y, 20), 0.05);
      state.camera.lookAt(0, 2, 0);
    }
  });
  return null;
}

export const Scene: React.FC = () => {
  const { isCameraActive } = useStore();

  return (
    <Canvas 
      gl={{ toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.2, antialias: false }}
      shadows
      dpr={[1, 2]}
    >
      <PerspectiveCamera makeDefault position={[0, 4, 20]} fov={50} />
      {!isCameraActive && <OrbitControls enablePan={false} maxPolarAngle={Math.PI / 1.5} minDistance={10} maxDistance={40} />}
      <CameraController />

      <Environment preset="lobby" background={false} />
      
      {/* Lighting for Luxury Feel */}
      <ambientLight intensity={0.2} color={COLORS.EMERALD_DEEP} />
      <spotLight position={[10, 20, 10]} angle={0.3} penumbra={1} intensity={2} castShadow color={COLORS.WARM_LIGHT} />
      <pointLight position={[-10, 5, -10]} intensity={1} color={COLORS.GOLD_HIGH} />
      <pointLight position={[0, -5, 5]} intensity={0.5} color={COLORS.RED_VELVET} />

      <Suspense fallback={null}>
        <group position={[0, -CONFIG.TREE_HEIGHT/3, 0]}>
          <Foliage />
          <Snow />
          
          {/* Base Presents - Heavy and Lots */}
          <Ornaments 
            count={60} 
            type="box" 
            colors={[COLORS.RED_VELVET, COLORS.GOLD_DARK, COLORS.EMERALD_DEEP, COLORS.SILVER]} 
            distribution="bottom"
            scaleMultiplier={1.5}
          />

          {/* Golden Bead Spiral Garland */}
          <Ornaments 
            count={600} 
            type="sphere" 
            colors={[COLORS.GOLD_HIGH]} 
            distribution="spiral" 
            scaleMultiplier={0.3}
          />

          {/* Standard Sphere Ornaments */}
          <Ornaments 
            count={120} 
            type="sphere" 
            colors={[COLORS.GOLD_HIGH, COLORS.SILVER, COLORS.RED_VELVET]} 
          />

          {/* Luxury Diamonds */}
          <Ornaments 
            count={50} 
            type="diamond" 
            colors={[COLORS.ICE_BLUE, COLORS.PURE_WHITE]} 
            scaleMultiplier={1.5}
          />

          {/* Hanging Icicles */}
          <Ornaments 
            count={40} 
            type="icicle" 
            colors={[COLORS.ICE_BLUE, COLORS.SILVER]} 
            scaleMultiplier={0.8}
          />

          {/* Fairy Lights */}
          <Ornaments 
            count={300} 
            type="light" 
            colors={[COLORS.GOLD_HIGH, COLORS.WARM_LIGHT]} 
          />
          
          <Polaroids />
          <TreeTopper />
        </group>
      </Suspense>

      <EffectComposer disableNormalPass>
        <Bloom luminanceThreshold={0.7} mipmapBlur intensity={1.5} radius={0.5} />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        <Noise opacity={0.02} />
      </EffectComposer>
    </Canvas>
  );
};
