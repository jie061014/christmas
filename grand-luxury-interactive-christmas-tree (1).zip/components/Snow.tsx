import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useStore } from '../store';
import { AppState } from '../types';

export const Snow: React.FC = () => {
  const count = 1000;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const mode = useStore(state => state.mode);
  
  const dummy = useMemo(() => new THREE.Object3D(), []);
  
  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < count; i++) {
      const x = (Math.random() - 0.5) * 40;
      const y = (Math.random() - 0.5) * 40;
      const z = (Math.random() - 0.5) * 40;
      const speed = 0.5 + Math.random();
      temp.push({ 
        pos: new THREE.Vector3(x, y, z), 
        velocity: new THREE.Vector3((Math.random()-0.5)*0.5, -speed, (Math.random()-0.5)*0.5),
        initialPos: new THREE.Vector3(x, y, z)
      });
    }
    return temp;
  }, []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    // In CHAOS mode, wind blows up/out
    const chaosFactor = mode === AppState.CHAOS ? 1 : 0;
    
    particles.forEach((p, i) => {
      // Basic gravity fall
      p.pos.y += p.velocity.y * delta * (1 - chaosFactor);
      p.pos.x += p.velocity.x * delta;
      p.pos.z += p.velocity.z * delta;

      // Chaos turbulence
      if (chaosFactor > 0.5) {
         p.pos.y += delta * 5; // Fly up
         p.pos.x += Math.sin(state.clock.elapsedTime * 2 + i) * delta * 2;
      }
      
      // Reset if out of bounds
      if (p.pos.y < -20) p.pos.y = 20;
      if (p.pos.y > 25) p.pos.y = -15;

      dummy.position.copy(p.pos);
      
      // Twinkle rotation
      dummy.rotation.x += delta;
      dummy.rotation.y += delta;
      
      dummy.scale.setScalar(0.05 + Math.sin(state.clock.elapsedTime * 3 + i) * 0.02);
      
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <tetrahedronGeometry args={[1, 0]} />
      <meshBasicMaterial color="#FFD700" transparent opacity={0.6} blending={THREE.AdditiveBlending} />
    </instancedMesh>
  );
};
