import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import { useStore } from '../store';
import { AppState } from '../types';
import { detectMotion } from '../services/gestureService';

export const Interface: React.FC = () => {
  const { mode, setMode, setHandPosition, setCameraActive, isCameraActive } = useStore();
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(document.createElement('canvas'));
  const prevFrame = useRef<Uint8ClampedArray | null>(null);
  
  // Motion thresholds
  const UNLEASH_THRESHOLD = 0.15; // Amount of motion to trigger Chaos
  
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    
    if (isCameraActive) {
      interval = setInterval(() => {
        if (webcamRef.current && webcamRef.current.video && webcamRef.current.video.readyState === 4) {
           const { activity, x, y, newFrame } = detectMotion(
             webcamRef.current.video,
             canvasRef.current,
             prevFrame.current
           );
           
           prevFrame.current = newFrame;

           // Smooth hand position update
           setHandPosition(x, y);

           // Logic: High motion (Waving hands/Open gesture movement) = CHAOS
           // Stillness (Closed/Calm) = FORMED
           if (activity > UNLEASH_THRESHOLD) {
             setMode(AppState.CHAOS);
           } else {
             setMode(AppState.FORMED);
           }
        }
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isCameraActive, setMode, setHandPosition]);

  return (
    <div className="absolute inset-0 pointer-events-none z-10 p-6 md:p-10 flex flex-col">
      {/* Header - Top Left */}
      <div className="pointer-events-auto self-start text-left mb-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-[#FFD700] tracking-widest drop-shadow-[0_2px_10px_rgba(255,215,0,0.5)]">
          GRAND LUXURY
        </h1>
        <h2 className="text-sm md:text-lg text-white font-light tracking-[0.4em] mt-2 opacity-80 pl-1">
          CHRISTMAS INTERACTIVE
        </h2>
      </div>

      {/* Controls - Sidebar Right */}
      <div className="pointer-events-auto absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-end gap-6">
        
        {/* Toggle Camera Button */}
        <button 
          onClick={() => setCameraActive(!isCameraActive)}
          className={`px-4 py-2 text-xs md:text-sm border border-[#FFD700] rounded-sm transition-all duration-500 uppercase tracking-widest backdrop-blur-md ${
            isCameraActive 
            ? 'bg-[#FFD700] text-black font-bold shadow-[0_0_20px_#FFD700]' 
            : 'text-[#FFD700] bg-black/30 hover:bg-[#FFD700/20]'
          }`}
        >
          {isCameraActive ? "Camera Active" : "Enable Camera"}
        </button>

        {/* Webcam View */}
        {isCameraActive && (
          <div className="relative w-32 h-24 md:w-48 md:h-36 border border-[#FFD700] rounded overflow-hidden shadow-2xl bg-black group">
            <Webcam
              ref={webcamRef}
              audio={false}
              className="w-full h-full object-cover opacity-80"
              mirrored
            />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
               <span className="text-[10px] text-[#FFD700] font-bold uppercase tracking-widest">Tracking</span>
            </div>
            {/* Corner Accents */}
            <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-[#FFD700]"></div>
            <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-[#FFD700]"></div>
          </div>
        )}

        {/* Manual Trigger Button (Square style for sidebar) */}
        {!isCameraActive && (
          <button 
            onMouseDown={() => setMode(AppState.CHAOS)}
            onMouseUp={() => setMode(AppState.FORMED)}
            onTouchStart={() => setMode(AppState.CHAOS)}
            onTouchEnd={() => setMode(AppState.FORMED)}
            className="group relative w-24 h-24 md:w-32 md:h-32 bg-black/20 backdrop-blur-sm border border-[#FFD700] text-[#FFD700] font-serif rounded-sm transition-all hover:bg-[#FFD700/10] hover:scale-105 active:scale-95 flex flex-col items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,0,0,0.5)]"
          >
            <div className="text-2xl md:text-3xl transition-transform group-hover:rotate-180 duration-700">❖</div>
            <span className="text-[8px] md:text-[10px] tracking-widest uppercase text-center font-bold">
              Hold to<br/>Unleash
            </span>
            <span className="absolute inset-0 border border-[#FFD700] scale-90 opacity-0 group-hover:opacity-100 group-hover:scale-95 transition-all duration-500"></span>
          </button>
        )}

        {/* Instructions Text */}
        <div className="text-[#FFD700]/70 text-[10px] max-w-[160px] text-right leading-relaxed font-sans uppercase tracking-wider bg-black/60 p-3 rounded backdrop-blur-md border-r-2 border-[#FFD700] shadow-lg">
          {isCameraActive 
            ? "Wave hands to destabilize structure. Remain still to reform."
            : "Press & Hold button to unleash chaos. Release to restore order."}
        </div>
      </div>
    </div>
  );
};
