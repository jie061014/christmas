import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useStore } from '../store';
import { AppState } from '../types';
import * as THREE from 'three';
import { COLORS, CONFIG } from '../constants';

export const TreeTopper: React.FC = () => {
  const ref = useRef<THREE.Group>(null);
  const mode = useStore(state => state.mode);
  const progress = useRef(0);

  const { shape, config } = useMemo(() => {
    const s = new THREE.Shape();
    const points = 5;
    const outerRadius = 1.3;
    const innerRadius = 0.6;
    
    for (let i = 0; i < points * 2; i++) {
      const r = i % 2 === 0 ? outerRadius : innerRadius;
      const angle = (i / points) * Math.PI;
      // Start from top (0, 1) direction so it points up nicely
      const x = Math.sin(angle) * r;
      const y = Math.cos(angle) * r;
      
      if (i === 0) s.moveTo(x, y);
      else s.lineTo(x, y);
    }
    s.closePath();

    const c = {
      depth: 0.4,
      bevelEnabled: true,
      bevelThickness: 0.1,
      bevelSize: 0.1,
      bevelSegments: 4
    };

    return { shape: s, config: c };
  }, []);

  useFrame((state, delta) => {
    if(!ref.current) return;
    
    const target = mode === AppState.CHAOS ? 1 : 0;
    progress.current = THREE.MathUtils.lerp(progress.current, target, delta * 1.5);
    
    // Explode upwards in Chaos
    const yPos = (CONFIG.TREE_HEIGHT / 2) + 0.5 + (progress.current * 5);
    ref.current.position.y = yPos;
    
    // Rotate continuously
    ref.current.rotation.y += delta * 0.8;
    // Add a bit of tilt wobble for liveliness
    ref.current.rotation.z = Math.sin(state.clock.elapsedTime * 2) * 0.05 * (1 + progress.current);
  });

  return (
    <group ref={ref} position={[0, CONFIG.TREE_HEIGHT/2, 0]}>
      {/* Center the extruded geometry by offsetting Z by approx half depth */}
      <mesh position={[0, 0, -0.2]}>
        <extrudeGeometry args={[shape, config]} />
        <meshPhysicalMaterial 
          color={COLORS.GOLD_HIGH}
          emissive={COLORS.GOLD_DARK}
          emissiveIntensity={0.8} 
          metalness={1}
          roughness={0.05} // High polish
          clearcoat={1}
          clearcoatRoughness={0}
        />
      </mesh>
      
      {/* Strong inner light for bloom effect */}
      <pointLight color={COLORS.GOLD_HIGH} intensity={8} distance={15} decay={2} />
    </group>
  );
};
