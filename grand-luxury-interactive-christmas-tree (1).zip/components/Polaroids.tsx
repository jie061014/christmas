import React, { useMemo, useRef } from 'react';
import { useFrame, useLoader } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, TEXTURE_URLS } from '../constants';
import { AppState } from '../types';
import { useStore } from '../store';

const Polaroid: React.FC<{ url: string; index: number }> = ({ url, index }) => {
  const texture = useLoader(THREE.TextureLoader, url);
  const meshRef = useRef<THREE.Group>(null);
  const mode = useStore((state) => state.mode);
  const animProgress = useRef(0);

  const { targetPos, chaosPos, rotation } = useMemo(() => {
    // Position on tree surface
    const yNorm = Math.random() * 0.8 + 0.1; // Middle of tree
    const y = (yNorm - 0.5) * CONFIG.TREE_HEIGHT;
    const r = (1 - yNorm) * CONFIG.TREE_RADIUS * 1.1; // Slightly outside
    const theta = (index / CONFIG.PHOTO_COUNT) * Math.PI * 2 + (Math.random() * 0.5);
    
    const target = new THREE.Vector3(r * Math.cos(theta), y, r * Math.sin(theta));
    
    // Chaos Position
    const r2 = 8 + Math.random() * 8;
    const chaos = new THREE.Vector3(
      (Math.random() - 0.5) * r2 * 2,
      (Math.random() - 0.5) * r2 * 2,
      (Math.random() - 0.5) * r2 * 2
    );

    const rot = new THREE.Euler(0, -theta + Math.PI/2, Math.random() * 0.2 - 0.1);

    return { targetPos: target, chaosPos: chaos, rotation: rot };
  }, [index]);

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    const target = mode === AppState.CHAOS ? 1 : 0;
    animProgress.current = THREE.MathUtils.lerp(animProgress.current, target, delta * 2.0);
    const t = animProgress.current;
    
    // Float movement
    const floatY = Math.sin(state.clock.elapsedTime + index) * 0.1;

    meshRef.current.position.lerpVectors(targetPos, chaosPos, t);
    meshRef.current.position.y += floatY;
    
    // Rotate in chaos
    if (t > 0.1) {
      meshRef.current.rotation.x = rotation.x + t * Math.sin(state.clock.elapsedTime * 0.5);
      meshRef.current.rotation.y = rotation.y + t * Math.cos(state.clock.elapsedTime * 0.3);
    } else {
      meshRef.current.rotation.copy(rotation);
    }
    
    // Look at camera if chaos
    if (mode === AppState.CHAOS) {
      meshRef.current.lookAt(state.camera.position);
    }
  });

  return (
    <group ref={meshRef} scale={0.8}>
      {/* White Frame */}
      <mesh position={[0, 0, -0.01]}>
        <boxGeometry args={[1.2, 1.5, 0.05]} />
        <meshStandardMaterial color="#fffff0" roughness={0.8} />
      </mesh>
      {/* Photo */}
      <mesh position={[0, 0.1, 0.02]}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial map={texture} />
      </mesh>
    </group>
  );
};

export const Polaroids: React.FC = () => {
  return (
    <group>
      {TEXTURE_URLS.map((url, i) => (
        <React.Fragment key={i}>
             {/* Repeat textures to hit count */}
             {Array.from({ length: 4 }).map((_, j) => (
                 <Polaroid key={`${i}-${j}`} url={url} index={i * 4 + j} />
             ))}
        </React.Fragment>
      ))}
    </group>
  );
};
