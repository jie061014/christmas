import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG } from '../constants';
import { AppState, OrnamentProps } from '../types';
import { useStore } from '../store';

export const Ornaments: React.FC<OrnamentProps> = ({ 
  count, 
  type, 
  colors, 
  distribution = 'random',
  scaleMultiplier = 1.0
}) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const mode = useStore((state) => state.mode);
  const animProgress = useRef(0);
  
  // Weights determine how fast they fly away/back. Heavy (boxes) are slower.
  const weightFactor = type === 'box' ? 1.5 : (type === 'light' ? 4.0 : 2.5);

  const { data } = useMemo(() => {
    const temp = [];
    const height = CONFIG.TREE_HEIGHT;
    const maxR = CONFIG.TREE_RADIUS;

    for (let i = 0; i < count; i++) {
      let targetPos = new THREE.Vector3();
      let rot = new THREE.Euler(Math.random(), Math.random(), Math.random());

      // --- Distribution Logic ---
      if (distribution === 'spiral') {
        // Spiral Garland
        const t = i / count; // 0 to 1
        const loops = 4; 
        const y = (t - 0.5) * height; // Bottom to top
        const r = (1 - t) * maxR * 1.05; // Slightly outside foliage
        const theta = t * Math.PI * 2 * loops;
        targetPos.set(r * Math.cos(theta), y, r * Math.sin(theta));
        rot.set(0, -theta, 0); // Align with spiral somewhat

      } else if (distribution === 'bottom') {
        // Presents under the tree
        const r = Math.random() * maxR * 1.5;
        const theta = Math.random() * Math.PI * 2;
        // Spread on floor, slightly piled up
        const y = (-height / 2) + 0.5 + (Math.random() * 1.5); 
        targetPos.set(r * Math.cos(theta), y, r * Math.sin(theta));
        rot.set(0, Math.random() * Math.PI, 0); // Flat on ground usually

      } else {
        // Random (Standard)
        const yNorm = Math.random();
        const y = (yNorm - 0.5) * height * 0.9;
        const r = (1 - yNorm) * maxR * 0.9; // Inside/Surface
        const theta = Math.random() * Math.PI * 2;
        targetPos.set(r * Math.cos(theta), y, r * Math.sin(theta));
      }

      // --- Chaos Logic ---
      const r2 = 10 + Math.random() * 20;
      const theta2 = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      const chaosPos = new THREE.Vector3(
        r2 * Math.sin(phi) * Math.cos(theta2),
        r2 * Math.sin(phi) * Math.sin(theta2),
        r2 * Math.cos(phi)
      );

      // --- Scale Logic ---
      let baseScale = 1;
      if (type === 'box') baseScale = Math.random() * 0.3 + 0.3;
      else if (type === 'light') baseScale = 0.08;
      else if (type === 'diamond') baseScale = 0.25;
      else if (type === 'icicle') baseScale = 1.0; // Geometry itself handles thinness
      else baseScale = 0.25;

      const scale = baseScale * scaleMultiplier;
      const color = new THREE.Color(colors[Math.floor(Math.random() * colors.length)]);
      
      temp.push({ targetPos, chaosPos, scale, color, rotation: rot });
    }
    return { data: temp };
  }, [count, type, colors, distribution, scaleMultiplier]);

  useLayoutEffect(() => {
    if (meshRef.current) {
      data.forEach((d, i) => {
        meshRef.current?.setColorAt(i, d.color);
      });
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [data]);

  const dummy = useMemo(() => new THREE.Object3D(), []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    const target = mode === AppState.CHAOS ? 1 : 0;
    animProgress.current = THREE.MathUtils.lerp(animProgress.current, target, delta * (CONFIG.ANIMATION_SPEED / weightFactor + 0.5));

    data.forEach((d, i) => {
      const t = animProgress.current;
      const smoothT = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

      const currentPos = new THREE.Vector3().lerpVectors(d.targetPos, d.chaosPos, smoothT);
      
      if (t > 0.1) {
        dummy.rotation.set(
          d.rotation.x + state.clock.elapsedTime * 0.2,
          d.rotation.y + state.clock.elapsedTime * 0.2,
          d.rotation.z
        );
      } else {
        dummy.rotation.copy(d.rotation);
      }
      
      dummy.position.copy(currentPos);
      
      if (type === 'icicle') {
         dummy.scale.set(d.scale * 0.15, d.scale * 1, d.scale * 0.15); // Skinny cones
      } else {
         dummy.scale.setScalar(d.scale);
      }
      
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  // Geometry & Material Selection (Memoized)
  const { geometry, material } = useMemo(() => {
    let geom, mat;
    if (type === 'box') {
      geom = new THREE.BoxGeometry(1, 1, 1);
      mat = new THREE.MeshPhysicalMaterial({ 
        color: 0xffffff, metalness: 0.1, roughness: 0.2, sheen: 1, sheenColor: 0xffffff 
      });
    } else if (type === 'sphere') {
      geom = new THREE.SphereGeometry(1, 16, 16);
      mat = new THREE.MeshPhysicalMaterial({ 
        color: 0xffffff, metalness: 0.8, roughness: 0.1, clearcoat: 1.0 
      });
    } else if (type === 'diamond') {
      geom = new THREE.OctahedronGeometry(1, 0);
      mat = new THREE.MeshPhysicalMaterial({ 
        color: 0xffffff, metalness: 1.0, roughness: 0.0, transmission: 0.2, thickness: 1 
      });
    } else if (type === 'icicle') {
      geom = new THREE.ConeGeometry(1, 2, 8); // Base 1, Height 2
      geom.translate(0, -1, 0); // Pivot at top
      mat = new THREE.MeshPhysicalMaterial({ 
        color: 0xffffff, metalness: 0.2, roughness: 0.1, transmission: 0.6, thickness: 2, transparent: true, opacity: 0.9 
      });
    } else {
      // Lights
      geom = new THREE.SphereGeometry(1, 8, 8);
      mat = new THREE.MeshBasicMaterial({ color: 0xffffff }); 
    }
    return { geometry: geom, material: mat };
  }, [type]);

  return (
    <instancedMesh ref={meshRef} args={[geometry, material, count]} />
  );
};
