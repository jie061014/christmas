// This service handles the "concept" of gesture detection.
// In a production app, this would load TensorFlow/MediaPipe.
// For this contained demo, we provide utilities to calculate "energy" from the video feed
// to simulate open/closed hand dynamics if ML fails to load, or just simple motion tracking.

export const detectMotion = (
  video: HTMLVideoElement, 
  canvas: HTMLCanvasElement, 
  prevFrame: Uint8ClampedArray | null
) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return { activity: 0, x: 0, y: 0, newFrame: null };

  const width = 64; // Low res for performance
  const height = 48;
  
  canvas.width = width;
  canvas.height = height;
  ctx.drawImage(video, 0, 0, width, height);
  
  const frame = ctx.getImageData(0, 0, width, height);
  const data = frame.data;
  const length = data.length;
  
  let diffScore = 0;
  let moveX = 0;
  let moveY = 0;
  let diffPixels = 0;

  if (prevFrame) {
    for (let i = 0; i < length; i += 4) {
      // Simple grayscale diff
      const r = Math.abs(data[i] - prevFrame[i]);
      const g = Math.abs(data[i+1] - prevFrame[i+1]);
      const b = Math.abs(data[i+2] - prevFrame[i+2]);
      const avgDiff = (r + g + b) / 3;

      if (avgDiff > 20) { // Threshold
        diffScore += avgDiff;
        diffPixels++;
        // Accumulate center of motion
        const pixelIdx = i / 4;
        const x = pixelIdx % width;
        const y = Math.floor(pixelIdx / width);
        moveX += x;
        moveY += y;
      }
    }
  }

  if (diffPixels > 0) {
    moveX /= diffPixels;
    moveY /= diffPixels;
    
    // Normalize -1 to 1
    moveX = (moveX / width) * 2 - 1;
    moveY = (moveY / height) * 2 - 1;
  }

  // Activity 0 to 1
  const activity = Math.min(diffScore / (width * height * 10), 1);

  return { activity, x: -moveX, y: -moveY, newFrame: data }; // Mirror X
};
